CREATE DATABASE  IF NOT EXISTS dbDesafioivia;

USE dbdesafioivia;

Drop table tbusuario;

CREATE TABLE tbusuario (
  Codigo int(11) NOT NULL AUTO_INCREMENT,
  Nome varchar(100) NOT NULL,
  senha varchar(8) NOT NULL,
  CPF varchar(14) NOT NULL,
  email varchar(100) NOT NULL,
  ddd varchar(3) NOT NULL,
  telefone varchar(18) NOT NULL,
  tipo varchar(20) NOT NULL,
  PRIMARY KEY (Codigo)
);

CREATE TABLE tborgao (
  Codigo int(11) NOT NULL AUTO_INCREMENT,
  Nome varchar(100) NOT NULL,
  PRIMARY KEY (Codigo)
);

CREATE TABLE tbcargo (
  Codigo int(11) NOT NULL AUTO_INCREMENT,
  Nome varchar(100) NOT NULL,
  PRIMARY KEY (Codigo)
);

CREATE TABLE tbsistema (
  Codigo int(11) NOT NULL AUTO_INCREMENT,
  Nome varchar(100) NOT NULL,
  PRIMARY KEY (Codigo)
);
