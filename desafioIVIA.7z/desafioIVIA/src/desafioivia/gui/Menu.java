package desafioivia.gui;

/**
 * Janela menu da aplicação
 *
 * @author Juliano
 */
public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        toolBar = new javax.swing.JToolBar();
        btUsuario = new javax.swing.JButton();
        btOrgao = new javax.swing.JButton();
        btCargo = new javax.swing.JButton();
        btSistema = new javax.swing.JButton();
        btSair = new javax.swing.JButton();
        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        menuCadastros = new javax.swing.JMenu();
        miCliente = new javax.swing.JMenuItem();
        miCargo = new javax.swing.JMenuItem();
        miOrgao = new javax.swing.JMenuItem();
        menuSistema = new javax.swing.JMenu();
        miSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Vendas");

        toolBar.setFloatable(false);

        btUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/cliente.png"))); // NOI18N
        btUsuario.setText("Usuário");
        btUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btUsuario.setFocusable(false);
        btUsuario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btUsuario.setMargin(new java.awt.Insets(2, 12, 2, 12));
        btUsuario.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/cliente-foco.png"))); // NOI18N
        btUsuario.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miClienteActionPerformed(evt);
            }
        });
        toolBar.add(btUsuario);

        btOrgao.setIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/compra.png"))); // NOI18N
        btOrgao.setText("Órgão");
        btOrgao.setToolTipText("");
        btOrgao.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btOrgao.setFocusable(false);
        btOrgao.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btOrgao.setMargin(new java.awt.Insets(2, 12, 2, 12));
        btOrgao.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/compra-foco.png"))); // NOI18N
        btOrgao.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btOrgao.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btOrgao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btOrgaomiCompraActionPerformed(evt);
            }
        });
        toolBar.add(btOrgao);

        btCargo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/fornecedor.png"))); // NOI18N
        btCargo.setText("Cargo");
        btCargo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btCargo.setFocusable(false);
        btCargo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btCargo.setMargin(new java.awt.Insets(2, 12, 2, 12));
        btCargo.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/fornecedor-foco.png"))); // NOI18N
        btCargo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCargomiFornecedorActionPerformed(evt);
            }
        });
        toolBar.add(btCargo);

        btSistema.setIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/produto-foco.png"))); // NOI18N
        btSistema.setText("Sistema");
        btSistema.setActionCommand("Sistema");
        btSistema.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btSistema.setFocusable(false);
        btSistema.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btSistema.setMargin(new java.awt.Insets(2, 12, 2, 12));
        btSistema.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/produto.png"))); // NOI18N
        btSistema.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btSistema.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSistemamiProdutoActionPerformed(evt);
            }
        });
        toolBar.add(btSistema);

        btSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/sair.png"))); // NOI18N
        btSair.setText("Sair");
        btSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btSair.setFocusable(false);
        btSair.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btSair.setMargin(new java.awt.Insets(2, 12, 2, 12));
        btSair.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/desafioivia/gui/img/sair-foco.png"))); // NOI18N
        btSair.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miSairActionPerformed(evt);
            }
        });
        toolBar.add(btSair);

        getContentPane().add(toolBar, java.awt.BorderLayout.PAGE_START);

        desktopPane.setOpaque(false);
        getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);

        menuCadastros.setText("Cadastros");

        miCliente.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        miCliente.setText("Cadastrar Cliente");
        miCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miClienteActionPerformed1(evt);
            }
        });
        menuCadastros.add(miCliente);

        miCargo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        miCargo.setActionCommand("Cadastrar Cargo");
        miCargo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        miCargo.setLabel("Cadastrar Cargo");
        miCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCargoActionPerformed(evt);
            }
        });
        menuCadastros.add(miCargo);

        miOrgao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        miOrgao.setText("Cadastrar Órgão");
        miOrgao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miOrgaoActionPerformed(evt);
            }
        });
        menuCadastros.add(miOrgao);

        menuBar.add(menuCadastros);

        menuSistema.setText("Sistema");

        miSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        miSair.setText("Sair");
        miSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miSairActionPerformed(evt);
            }
        });
        menuSistema.add(miSair);

        menuBar.add(menuSistema);

        setJMenuBar(menuBar);

        setSize(new java.awt.Dimension(737, 662));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void miSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_miSairActionPerformed

    private void miCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miCargoActionPerformed
        CadastroCargo c = new CadastroCargo();
        desktopPane.add(c);
        c.setVisible(true);
    }//GEN-LAST:event_miCargoActionPerformed

    private void miClienteActionPerformed1(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miClienteActionPerformed1
        CadastroUsuario c = new CadastroUsuario();
        desktopPane.add(c);
        c.setVisible(true);
    }//GEN-LAST:event_miClienteActionPerformed1

    private void miOrgaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miOrgaoActionPerformed
        CadastroOrgao o = new CadastroOrgao();
        desktopPane.add(o);
        o.setVisible(true);
        
    }//GEN-LAST:event_miOrgaoActionPerformed

    private void miClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miClienteActionPerformed
        CadastroUsuario c = new CadastroUsuario();
        desktopPane.add(c);
        c.setVisible(true);
    }//GEN-LAST:event_miClienteActionPerformed

    private void btOrgaomiCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btOrgaomiCompraActionPerformed
        CadastroOrgao o = new CadastroOrgao();
        desktopPane.add(o);
        o.setVisible(true);
    }//GEN-LAST:event_btOrgaomiCompraActionPerformed

    private void btCargomiFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCargomiFornecedorActionPerformed
        CadastroCargo c = new CadastroCargo();
        desktopPane.add(c);
        c.setVisible(true);
    }//GEN-LAST:event_btCargomiFornecedorActionPerformed

    private void btSistemamiProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSistemamiProdutoActionPerformed
        CadastroSistema c = new CadastroSistema();
        desktopPane.add(c);
        c.setVisible(true);
    }//GEN-LAST:event_btSistemamiProdutoActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btCargo;
    private javax.swing.JButton btOrgao;
    private javax.swing.JButton btSair;
    private javax.swing.JButton btSistema;
    private javax.swing.JButton btUsuario;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuCadastros;
    private javax.swing.JMenu menuSistema;
    private javax.swing.JMenuItem miCargo;
    private javax.swing.JMenuItem miCliente;
    private javax.swing.JMenuItem miOrgao;
    private javax.swing.JMenuItem miSair;
    private javax.swing.JToolBar toolBar;
    // End of variables declaration//GEN-END:variables
}
