package desafioivia.dao;

import desafioivia.to.Sistema;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * Classe de acesso a dados do cliente
 *
 * @author Cristiano
 */
public class SistemaDAO implements IDAO<Sistema> {

    @Override
    public void inserir(Sistema sistema) throws Exception {
        Conexao c = new Conexao();
        String sql = "INSERT INTO TBSISTEMA (NOME) VALUES (?)";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, sistema.getSistema());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void alterar(Sistema sistema) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE TBSISTEMA SET NOME=? WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, sistema.getSistema());
        ps.setInt(2, sistema.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void excluir(Sistema sistema) throws Exception {
        Conexao c = new Conexao();
        String sql = "DELETE FROM TBSISTEMA WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, sistema.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public ArrayList<Sistema> listarTodos() throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBSISTEMA ORDER BY NOME";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        ArrayList listaSistemas = new ArrayList();
        while (rs.next()) {
            Sistema sistema = new Sistema();
            sistema.setCodigo(rs.getInt("CODIGO"));
            sistema.setSistema(rs.getString("NOME"));
            listaSistemas.add(sistema);
        }

        return listaSistemas;
    }

    @Override
    public Sistema recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBSISTEMA WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        
        Sistema sistema = new Sistema();
        if (rs.next()) {
            sistema.setSistema(rs.getString("NOME"));
        }

        return sistema;
    }
}
