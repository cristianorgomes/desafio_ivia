package desafioivia.dao;

import desafioivia.to.Cliente;
import desafioivia.to.Cargo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;

/**
 * Classe de acesso a dados do cliente
 *
 * @author Cristiano
 */
public class ClienteDAO implements IDAO<Cliente> {

    
    
    
    
    @Override
    public void inserir(Cliente cliente) throws Exception {
        Conexao c = new Conexao();
        String sql = "INSERT INTO TBUSUARIO (NOME, CPF, SENHA, EMAIL, DDD, TELEFONE, TIPO) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, cliente.getNome());
        ps.setString(2, cliente.getCpf());
        ps.setString(3, cliente.getSenha());
        ps.setString(4, cliente.getEmail());
        ps.setString(5, cliente.getDdd());
        ps.setString(6, cliente.getTelefone());
        ps.setString(7, cliente.getTipo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void alterar(Cliente cliente) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE TBUSUARIO SET NOME=?, SENHA=?, EMAIL=?, DDD=?, TELEFONE=?, TIPO=? WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, cliente.getNome());
        ps.setString(2, cliente.getSenha());
        ps.setString(3, cliente.getEmail());
        ps.setString(4, cliente.getDdd());
        ps.setString(5, cliente.getTelefone());
        ps.setString(6, cliente.getTipo());
        ps.setInt(7, cliente.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void excluir(Cliente cliente) throws Exception {
        Conexao c = new Conexao();
        String sql = "DELETE FROM TBUSUARIO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, cliente.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public ArrayList<Cliente> listarTodos() throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBUSUARIO ORDER BY NOME";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        ArrayList listaClientes = new ArrayList();
        while (rs.next()) {
            Cliente cliente = new Cliente();
            cliente.setCodigo(rs.getInt("CODIGO"));
            cliente.setNome(rs.getString("NOME"));
            cliente.setCpf(rs.getString("CPF"));
            cliente.setEmail(rs.getString("EMAIL"));
            cliente.setSenha(rs.getString("SENHA"));
            cliente.setDdd(rs.getString("DDD"));
            cliente.setTelefone(rs.getString("TELEFONE"));
            cliente.setTipo(rs.getString("TIPO"));
            listaClientes.add(cliente);
        }

        return listaClientes;
    }

    @Override
    public Cliente recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBUSUARIO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        
        Cliente cliente = new Cliente();
        if (rs.next()) {
            cliente.setNome(rs.getString("NOME"));
            cliente.setCpf(rs.getString("CPF"));
            cliente.setEmail(rs.getString("EMAIL"));
            cliente.setSenha(rs.getString("SENHA"));         
            cliente.setDdd(rs.getString("DDD"));
            cliente.setTelefone(rs.getString("TELEFONE"));
            cliente.setTipo(rs.getString("TIPO"));
        }

        return cliente;
    }
}
