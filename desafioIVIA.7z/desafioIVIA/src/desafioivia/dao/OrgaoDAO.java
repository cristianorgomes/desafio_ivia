package desafioivia.dao;

import desafioivia.to.Orgao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * Classe de acesso a dados do cliente
 *
 * @author Cristiano
 */
public class OrgaoDAO implements IDAO<Orgao> {

    @Override
    public void inserir(Orgao orgao) throws Exception {
        Conexao c = new Conexao();
        String sql = "INSERT INTO TBORGAO (NOME) VALUES (?)";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, orgao.getOrgao());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void alterar(Orgao orgao) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE TBORGAO SET NOME=? WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, orgao.getOrgao());
        ps.setInt(2, orgao.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void excluir(Orgao orgao) throws Exception {
        Conexao c = new Conexao();
        String sql = "DELETE FROM TBORGAO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, orgao.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public ArrayList<Orgao> listarTodos() throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBORGAO ORDER BY NOME";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        ArrayList listaOrgaos = new ArrayList();
        while (rs.next()) {
            Orgao orgao = new Orgao();
            orgao.setCodigo(rs.getInt("CODIGO"));
            orgao.setOrgao(rs.getString("NOME"));
            listaOrgaos.add(orgao);
        }

        return listaOrgaos;
    }

    @Override
    public Orgao recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBORGAO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        
        Orgao orgao = new Orgao();
        if (rs.next()) {
            orgao.setOrgao(rs.getString("NOME"));
        }

        return orgao;
    }
}
