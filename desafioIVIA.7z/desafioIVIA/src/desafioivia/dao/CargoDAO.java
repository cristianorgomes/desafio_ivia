package desafioivia.dao;

import desafioivia.to.Cargo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * Classe de acesso a dados do cliente
 *
 * @author Cristiano
 */
public class CargoDAO implements IDAO<Cargo> {

    @Override
    public void inserir(Cargo cargo) throws Exception {
        Conexao c = new Conexao();
        String sql = "INSERT INTO TBCARGO (NOME) VALUES (?)";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, cargo.getCargo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void alterar(Cargo cargo) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE TBCARGO SET NOME=? WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setString(1, cargo.getCargo());
        ps.setInt(2, cargo.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public void excluir(Cargo cargo) throws Exception {
        Conexao c = new Conexao();
        String sql = "DELETE FROM TBCARGO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, cargo.getCodigo());
        ps.execute();
        c.confirmar();
    }

    @Override
    public ArrayList<Cargo> listarTodos() throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBCARGO ORDER BY NOME";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        ArrayList listaCargos = new ArrayList();
        while (rs.next()) {
            Cargo cargo = new Cargo();
            cargo.setCodigo(rs.getInt("CODIGO"));
            cargo.setCargo(rs.getString("NOME"));
            listaCargos.add(cargo);
        }

        return listaCargos;
    }

    @Override
    public Cargo recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBCARGO WHERE CODIGO=?";
        PreparedStatement ps = c.getConexao().prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        
        Cargo cargo = new Cargo();
        if (rs.next()) {
            cargo.setCargo(rs.getString("NOME"));
        }

        return cargo;
    }
}
