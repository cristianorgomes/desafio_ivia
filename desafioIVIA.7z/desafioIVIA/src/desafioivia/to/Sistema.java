package desafioivia.to;

//import com.sun.org.apache.xerces.internal.xs.StringList;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
/**
 * Classe contendo os dados do cliente
 *
 * @author Cristiano
 */
public class Sistema {

    private int codigo;
    private String sistema;

    public Sistema() {
        this.codigo = 0;
        this.sistema = "";
    }

    public Sistema(int Codigo) {
        this.codigo = Codigo;
        this.sistema = "";
    }

    public String getSistema() {
        return sistema;
    }

    public void setSistema(String sistema) {
        this.sistema = sistema;
    }
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
