package desafioivia.to;

//import com.sun.org.apache.xerces.internal.xs.StringList;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
/**
 * Classe contendo os dados do cliente
 *
 * @author Cristiano
 */
public class Orgao {

    private int codigo;
    private String orgao;

    public Orgao() {
        this.codigo = 0;
        this.orgao = "";
    }

    public Orgao(int Codigo) {
        this.codigo = Codigo;
        this.orgao = "";
    }

    public String getOrgao() {
        return orgao;
    }

    public void setOrgao(String orgao) {
        this.orgao = orgao;
    }
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
