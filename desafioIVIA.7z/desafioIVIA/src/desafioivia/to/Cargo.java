package desafioivia.to;

//import com.sun.org.apache.xerces.internal.xs.StringList;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
/**
 * Classe contendo os dados do cliente
 *
 * @author Cristiano
 */
public class Cargo {

    private int codigo;
    private String cargo;

    public Cargo() {
        this.codigo = 0;
        this.cargo = "";
    }

    public Cargo(int Codigo) {
        this.codigo = Codigo;
        this.cargo = "";
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
