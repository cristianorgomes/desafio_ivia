package desafioivia.to;

//import com.sun.org.apache.xerces.internal.xs.StringList;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
/**
 * Classe contendo os dados do cliente
 *
 * @author Cristiano
 */
public class Cliente {

    private int codigo;
    private String nome;
    private String cpf;
    private String email;
    private String senha;
    private String ddd; 
    private String telefone; 
    private String tipo; 

    public Cliente() {
        this.codigo = 0;
        this.nome = "";
        this.cpf = "";
        this.senha = "";
        this.email = "";
        this.ddd = "";
        this.telefone = "";
        this.tipo = "";
    }

    public Cliente(int Codigo) {
        this.codigo = Codigo;
        this.cpf = "";
        this.nome = "";
        this.senha = "";
        this.email = "";
        this.telefone = "";
        this.ddd = "";
        this.telefone = "";
        this.tipo = "";
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDdd() {
        return ddd;
    }

    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
